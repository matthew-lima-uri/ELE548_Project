// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xmnist_dnn.h"

extern XMnist_dnn_Config XMnist_dnn_ConfigTable[];

XMnist_dnn_Config *XMnist_dnn_LookupConfig(u16 DeviceId) {
	XMnist_dnn_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMNIST_DNN_NUM_INSTANCES; Index++) {
		if (XMnist_dnn_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMnist_dnn_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMnist_dnn_Initialize(XMnist_dnn *InstancePtr, u16 DeviceId) {
	XMnist_dnn_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMnist_dnn_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMnist_dnn_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

