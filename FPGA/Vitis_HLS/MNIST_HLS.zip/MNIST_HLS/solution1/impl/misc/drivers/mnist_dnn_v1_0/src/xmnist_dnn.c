// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xmnist_dnn.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMnist_dnn_CfgInitialize(XMnist_dnn *InstancePtr, XMnist_dnn_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMnist_dnn_Start(XMnist_dnn *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMnist_dnn_ReadReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMnist_dnn_WriteReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMnist_dnn_IsDone(XMnist_dnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMnist_dnn_ReadReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMnist_dnn_IsIdle(XMnist_dnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMnist_dnn_ReadReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMnist_dnn_IsReady(XMnist_dnn *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMnist_dnn_ReadReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMnist_dnn_EnableAutoRestart(XMnist_dnn *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMnist_dnn_WriteReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMnist_dnn_DisableAutoRestart(XMnist_dnn *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMnist_dnn_WriteReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_AP_CTRL, 0);
}

void XMnist_dnn_InterruptGlobalEnable(XMnist_dnn *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMnist_dnn_WriteReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_GIE, 1);
}

void XMnist_dnn_InterruptGlobalDisable(XMnist_dnn *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMnist_dnn_WriteReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_GIE, 0);
}

void XMnist_dnn_InterruptEnable(XMnist_dnn *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMnist_dnn_ReadReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_IER);
    XMnist_dnn_WriteReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_IER, Register | Mask);
}

void XMnist_dnn_InterruptDisable(XMnist_dnn *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMnist_dnn_ReadReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_IER);
    XMnist_dnn_WriteReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMnist_dnn_InterruptClear(XMnist_dnn *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMnist_dnn_WriteReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_ISR, Mask);
}

u32 XMnist_dnn_InterruptGetEnabled(XMnist_dnn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMnist_dnn_ReadReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_IER);
}

u32 XMnist_dnn_InterruptGetStatus(XMnist_dnn *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMnist_dnn_ReadReg(InstancePtr->Control_BaseAddress, XMNIST_DNN_CONTROL_ADDR_ISR);
}

