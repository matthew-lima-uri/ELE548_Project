// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XMNIST_DNN_H
#define XMNIST_DNN_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmnist_dnn_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XMnist_dnn_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XMnist_dnn;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMnist_dnn_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMnist_dnn_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMnist_dnn_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMnist_dnn_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XMnist_dnn_Initialize(XMnist_dnn *InstancePtr, u16 DeviceId);
XMnist_dnn_Config* XMnist_dnn_LookupConfig(u16 DeviceId);
int XMnist_dnn_CfgInitialize(XMnist_dnn *InstancePtr, XMnist_dnn_Config *ConfigPtr);
#else
int XMnist_dnn_Initialize(XMnist_dnn *InstancePtr, const char* InstanceName);
int XMnist_dnn_Release(XMnist_dnn *InstancePtr);
#endif

void XMnist_dnn_Start(XMnist_dnn *InstancePtr);
u32 XMnist_dnn_IsDone(XMnist_dnn *InstancePtr);
u32 XMnist_dnn_IsIdle(XMnist_dnn *InstancePtr);
u32 XMnist_dnn_IsReady(XMnist_dnn *InstancePtr);
void XMnist_dnn_EnableAutoRestart(XMnist_dnn *InstancePtr);
void XMnist_dnn_DisableAutoRestart(XMnist_dnn *InstancePtr);


void XMnist_dnn_InterruptGlobalEnable(XMnist_dnn *InstancePtr);
void XMnist_dnn_InterruptGlobalDisable(XMnist_dnn *InstancePtr);
void XMnist_dnn_InterruptEnable(XMnist_dnn *InstancePtr, u32 Mask);
void XMnist_dnn_InterruptDisable(XMnist_dnn *InstancePtr, u32 Mask);
void XMnist_dnn_InterruptClear(XMnist_dnn *InstancePtr, u32 Mask);
u32 XMnist_dnn_InterruptGetEnabled(XMnist_dnn *InstancePtr);
u32 XMnist_dnn_InterruptGetStatus(XMnist_dnn *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
